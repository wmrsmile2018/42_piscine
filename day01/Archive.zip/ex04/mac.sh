#!/bin/sh
ifconfig -a | grep 'ether ' | cut -d ' ' -f 2
echo ""
