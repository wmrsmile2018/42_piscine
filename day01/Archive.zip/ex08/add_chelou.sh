echo "13o 5i $(echo $FT_NBR2 | tr "mrdoc" "01234") $(echo $FT_NBR1 | tr "\'\\\\\"\?\!" "01234")+p" | dc | tr "0123456789ABC" "gtaio luSnemf"

